﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class play : MonoBehaviour
{

    public void PlayGame()
    {
        SceneManager.LoadScene(1);
    }
}